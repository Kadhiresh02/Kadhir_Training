import React from "react";
import tiger from '../../assets/images/tiger.jpg'
import lion from '../../assets/images/lion.jpg'
import zebra from '../../assets/images/zebra.jpg'
import elephant from '../../assets/images/elephant.jpg'
const commonData={
    tiger,lion,zebra,elephant
}
export default commonData;