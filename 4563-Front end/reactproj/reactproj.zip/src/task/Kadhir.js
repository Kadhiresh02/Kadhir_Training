const KadhirFunComp = (props) =>{
    return (
        <p>First Name:{props.fname}<br/>Last Name: {props.lname}<br/>Salary:{props.salary}<br/>Gender :{props.gender}<br/>Address:{props.address}</p>
    )
}
export default KadhirFunComp;